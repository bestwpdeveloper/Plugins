=== Blogs Column Data ===
Contributors: bestwpdeveloper, ferdaussk
Donate link: https://bestwpdeveloper.com/
Tags: administration, column, user, admin
Requires at least: 5.0
Tested up to: 5.5
Requires PHP: 5.6
License: GPl V2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Stable tag: trunk

A simple and nice plugin to see some blogs column. And also it'll be helpful for knowing every blogs ID's and you'll that how many words have in these blogs and also you can filter your blogs with a thumbnails base.

== Description ==
A simple and nice plugin to see some blogs column. And also it'll be helpful for knowing every blog ID's and you'll that how mutch word has in this blogs and also you can filter your blogs with thumbnails base. This plugin will be helpful for an admin or developers. In this case, he can see the id of the blogs easily. If you want to see your plugin fetures then you have to just install (You can Download also) the plugin from WordPress.org and then you have to active the plugin. As a admin then you have to click Posts or Pages options menu. Then you can see three extra columns and also you can see exra filter field to filter has thumbnail for Posts page. 

Unblocking a user is easy. Assign them to their previous role and you're done!

== Installation ==
Installation is fairly straightforward. Install it from the WordPress plugin repository.
If you don't now then go to wordpress.org and Download from here then install(Go to Dashboard click on Plugins->Add New->Upload Plugin->Choose File->Install Now->Active). Also go to your WordPress Dashboard then Select Plugins->Add New->Search->Install->Active

== Changelog ==
= 1.0 =
* A change since the previous version.
* Another change.

== Frequently Asked Questions ==
If I want to see my posts and pages ID's is it available to see?
Yes, You can see all pages or posts ID.
Can I see blogs all word numbers?
Yes, You can see how many words have in this plugin.
Can I filter my post with thumbnails?
Yes, You can filter your post with has thumbnail base.
Can I see my post visitors?
No, Right now it's not available but we think about that in the future.
Have it pro version?
No, We aren't update in pro yet.

== Upgrade Notice ==
The plugin last updated virsion is 1.0.0

== Screenshots ==
https://bestwpdeveloper.com/wp-content/uploads/2021/12/blogs-column-data.png

= 1.0.0 =
* Initial Release


